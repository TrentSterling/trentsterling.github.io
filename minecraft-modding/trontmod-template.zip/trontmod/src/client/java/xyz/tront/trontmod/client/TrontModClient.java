package xyz.tront.trontmod.client;

import net.fabricmc.api.ClientModInitializer;

public class TrontModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Client-only setup (rendering, keybinds, screens) goes here. Nothing needed for a plain item.
	}
}
