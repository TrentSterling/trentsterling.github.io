package xyz.tront.trontmod;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * TUTORIAL(2.2): the entrypoint. fabric.mod.json names this class under "entrypoints.main", so Fabric
 * constructs it and calls onInitialize() once at startup, on both client and dedicated server.
 */
public class TrontMod implements ModInitializer {
	/** The namespace of every id this mod owns (trontmod:emerald_sword). Also the folder name under assets/ and data/. */
	public static final String MOD_ID = "trontmod";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// Runs once the game is mod-load-ready. Registries are open; no world or player exists yet.
		ModItems.initialize();
		LOGGER.info("TrontMod loaded");   // grep logs/latest.log for this line to prove the mod ran
	}

	/** trontmod:<path>. Use this everywhere instead of spelling the namespace out. */
	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
